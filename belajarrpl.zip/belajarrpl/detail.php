<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail siswa</title>
</head>
<body>
    <table border = "1" cellspacing = "0" cellpadding = "3">
        <tr>
            <td rowspan = "3"><img src = "image/GANDUM.jfif" width = "400"></td>
            <td>Nama</td>
            <td>Gandum</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>Konoha</td>
        </tr>
        <tr>
            <td>Telepon</td>
            <td>085731941143</td>
        </tr>
    </table>
</body>
</html>