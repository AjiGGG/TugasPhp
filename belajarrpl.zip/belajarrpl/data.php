<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa</title>
</head>
<body>
    <h1>Data Siswa</h1>
    <table border = "1" cellpadding = "2" cellspacing = "0">
        <tr>
            <td>No</td>
            <td>Foto</td>
            <td>Nama</td>
            <td>Aksi</td>
        </tr>
        <tr>
            <td>1</td>
            <td><img src = "image/GUNDAM.jfif" width = 250></td>
            <td><p1>Gandum 1</p1></td>
            <td><a href = "detail.php"><button type = "submit">Detail</button></a></td>
        </tr>
        <tr>
            <td>2</td>
            <td><img src = "image/GANDUM.jfif" width = 250></td>
            <td><p1>Gandum 2</p1></td>
            <td><a href = "detail.php"><button type = "submit">Detail</button></a></td>
        </tr>
        <tr>
            <td>3</td>
            <td><img src = "image/GUNDAM.jfif" width = 250></td>
            <td><p1>Gandum 3</p1></td>
            <td><a href = "detail.php"><button type = "submit">Detail</button></a></td>
        </tr>
        <tr>
            <td>4</td>
            <td><img src = "image/GANDUM.jfif" width = 250></td>
            <td><p1>Gandum 4</p1></td>
            <td><a href = "detail.php"><button type = "submit">Detail</button></a></td>
        </tr>
    </table>
</body>
</html>